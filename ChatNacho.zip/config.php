<?php
define('DB_HOST', 'localhost');
define('DB_USER', 'nachete');
define('DB_PASSWORD', 'nash256');
define('DB_DATABASE', 'chat_nacho');

require_once('FirePHPCore/FirePHP.class.php');
#Start buffering the output. Not required if output_buffering is set on in php.ini file
ob_start();
#get a firePHP variable reference


